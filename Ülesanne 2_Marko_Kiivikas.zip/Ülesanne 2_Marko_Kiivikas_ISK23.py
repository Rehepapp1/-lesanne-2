# Impordime vajalikud teegid
import pygame
import sys

# Alustame pygame'i
pygame.init()

# Määrame akna suuruse
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption("Harjutamine")

# Laeme taustapildi
bg_shop = pygame.image.load("bg_shop.png")

# Laeme müüja pildi ja muudame selle suurust
seller = pygame.image.load("seller.png")
seller = pygame.transform.scale(seller, [250, 305])

# Laeme jutukasti pildi ja muudame selle suurust
chat = pygame.image.load("chat.png")
chat = pygame.transform.scale(chat, [255, 210])

# Määrame fondi ja suuruse
font = pygame.font.SysFont('Sans', 20)

# Määrame teksti jutukasti jaoks
text = "Tere, olen Marko Kiivikas"

# Käivitame mängu tsükli
running = True
while running:
    # Kontrollime sündmusi
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Kuvame taustapildi (0, 0) asukohast alates
    screen.blit(bg_shop, (0, 0))
    screen.blit(seller, [108, 160])
    screen.blit(chat, [246, 65])

    # Kuvame teksti
    text_surface = font.render(text, True, (255, 255, 255))
    text_rect = text_surface.get_rect(center=(370, 163))
    screen.blit(text_surface, text_rect.topleft)

    # Uuendame ekraani
    pygame.display.flip()

# Lõpetame pygame'i
pygame.quit()
sys.exit()
